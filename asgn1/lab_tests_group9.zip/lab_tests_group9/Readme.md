### Note that our language COOL inherently doesn't support Hex
Characters. Hence we don't recognize them as token.###
