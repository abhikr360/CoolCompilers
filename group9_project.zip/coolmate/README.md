This is our compiler Project

Source language - COOL [coolmate]
Implementation language - python
Destination - Mips

Usage : 
	```./coolmate file_name1.cl file_name2.cl ... file_namen.cl```

Remark : last file should contain the Main class and main() function.

Team Members : 
 + Abhishek Kumar	150035 
 + Madhukant		150368
 + Tushar Gupta		150771
