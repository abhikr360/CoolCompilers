This is sublime-text Editor Plugin for coolmate Language which is derived from COOL (Classroom Object Oriented Language)

Usage : 

1. Unzip the zip file
2. Copy the following three files/folder - 
	cool.sublime-package
	cool.sublime-setting
	cool.sublime-syntax

	in ~/.config/sublime-text-X/Packages/Users/

X = sublime version 1 or 2 or 3

and Done !!




Reference : 

	It has been completely derived from java plugin of sublime-text editor. We have used base of 
	java plugin and added 
	+ Color coding for COOL constructs
	+ Nested line commenting on comment shortcut (Ctrl-/) 
	+ Auto-Complete with COOL program constructs


